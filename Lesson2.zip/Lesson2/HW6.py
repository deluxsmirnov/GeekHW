print('Необходимо ввести количество вводимых товаров, название товара, цену и кол-во товара на складе')
quantity = int(input('Введите сколько какое кол-во товаров будете вводить '))
i = 0
spisok_product = []
common = []
while i < quantity:
    product = input('Введите название товара ')
    price = input('Укажите стоимость товара ')
    quantity_product = input('Введите кол-во на складе ')
    my_dict = dict([('название', product),('цена', price),('количество', quantity_product),('ед', 'шт')])
    spisok_product.append(my_dict)
    i += 1
for i in enumerate(spisok_product, 1):
    common.append(i)
print(common)
