some_num = int(input("Введи любое число "))
sum_two = str(some_num) *2
sum_three = str(some_num) * 3
sentence_two = 'Ваше число, как сложение строки дважды'
sentence_three = 'Ваше число, как сложение строки дважды'
result = int(some_num) + int(sum_two) + int(sum_three)
print(f'Ваше число {some_num}. {sentence_two} = {sum_two}. {sentence_three} = {sum_three}, результат сложения {some_num} + {sum_two} + {sum_three} = {result}')
