name_firm = 'ПупкинКо'
valuta = 'USD'
revenue = float(input('Какой ваша выручка в месяц? '))
cost = float(input('Какие ваши затраты на фирму? '))
result = revenue - cost
if result > 0:
    print(f"Ваша фирма {name_firm} работает в прибыль {result:.2f} {valuta}")
    human = int(input(f'Сколько в Вашей фирме {name_firm} работает сотрудников? '))
    print(f'Каждый сотрудник Вашей фирмы получит премию с прибыли в размере {result/human:.2f}{valuta}')
elif result < 0:
    print(f"Ваша фирма {name_firm} работает в убыток {result:.2f} {valuta}")
else:
    print(f"Ваша фирма {name_firm} работает в {result}")


