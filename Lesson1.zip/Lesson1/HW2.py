time_sec = int(input("Введите время в секундах, я его преобразую в часы/минуты/секунды "))
hours = time_sec // 3600
minutes = (time_sec // 60) - (hours * 60)

print('{:02}:{:02}:{:02}'.format(hours, minutes,time_sec % 60))
