my_name = "Serezha"
my_age = 29
privet = "Привет пользователь"
name = input("Как тебя зовут? ")
city = input("Из какого ты города? ")
age = int(input('Сколько тебе полных лет? '))
print(my_name + ' ' + str(my_age))
print("{}  {}, из славного города {} , твой возраст {} года/лет".format(privet, name, city, age))

