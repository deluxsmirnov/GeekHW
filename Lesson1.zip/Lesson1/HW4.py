some_number = int(input("Введите число. Моя программа скажет самую большую цифру в нём "))
ostatok = some_number % 10
some_number = some_number // 10
while some_number > 0:
    if some_number % 10 > ostatok:
        ostatok = some_number % 10
    some_number = some_number // 10

print ("В вашем числе наибольшая цифра {}".format(ostatok))


